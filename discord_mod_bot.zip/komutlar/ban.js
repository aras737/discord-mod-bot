module.exports = {
    name: 'ban',
    execute(message, args) {
        if (!message.member.permissions.has("BanMembers")) return message.reply("Yetkin yok!");
        const member = message.mentions.members.first();
        if (!member) return message.reply("Bir kullanıcı etiketlemelisin!");
        member.ban().then(() => {
            message.channel.send(`${member.user.tag} banlandı.`);
        });
    }
}