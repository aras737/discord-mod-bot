module.exports = {
    name: 'kick',
    execute(message, args) {
        if (!message.member.permissions.has("KickMembers")) return message.reply("Yetkin yok!");
        const member = message.mentions.members.first();
        if (!member) return message.reply("Bir kullanıcı etiketlemelisin!");
        member.kick().then(() => {
            message.channel.send(`${member.user.tag} atıldı.`);
        });
    }
}