# Discord Moderasyon Botu

- `ping` komutu örnek olarak eklenmiştir.
- `.env` dosyasına tokenınızı girmeniz yeterlidir.
